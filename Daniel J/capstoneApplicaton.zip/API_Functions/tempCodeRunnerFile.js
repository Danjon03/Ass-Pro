
        .then((response) => response.json())
        .then((data) => {
            console.log(data);
        });
}

//Uncomment these lines to test them
//getUsers();

loginUser("danjon0"